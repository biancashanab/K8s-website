Vvveb.Sections.add("roxo/privacy-policy", {
    name: "Privacy policy",
    image: Vvveb.themeBaseUrl + "/screenshots/roxo/privacy-policy-thumb.jpeg",
    html: `<section class="site-project-single-section">
  <div class="container">
    <div class="row">
      <div class="col-lg-8 mx-auto">
        <div class="site-project-single">
          <h1>
            Privacy & Policy
          </h1>
          <div class="site-project-single-description">
            <h4>What is Lorem Ipsum?</h4>
            <p>
              Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum
            </p>
            <h4>What is Lorem Ipsum?</h4>
            <p>
              Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum
            </p>
            <h4>What is Lorem Ipsum?</h4>
            <p>
              Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum
            </p>
            <h4>What is Lorem Ipsum?</h4>
            <p>
              Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum
            </p>
            <h4>What is Lorem Ipsum?</h4>
            <p>
              Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum
            </p>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>`
});Vvveb.Sections.add("roxo/site-about-header", {
    name: "Site about header",
    image: Vvveb.themeBaseUrl + "/screenshots/roxo/site-about-header-thumb.jpeg",
    html: `<section class="site-about-header">
  <div class="container">
    <div class="row">
      <div class="col-12">
        <div class="site-about-wrapper">
          <div class="site-about-company">
            <h1>
              We are roxo design.
              <br>
              An award-winning creative studio in Florida.
            </h1>
          </div>
          <div class="site-about-description">
            <p>
              We are specialized in developing forward-thinking brand identities, websites, illustration and animation for all types of customers. And we do this by bringing our customers through each phase of the design process with us.
            </p>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>`
});Vvveb.Sections.add("roxo/site-blog-header", {
    name: "Site blog header",
    image: Vvveb.themeBaseUrl + "/screenshots/roxo/site-blog-header-thumb.jpeg",
    html: `<section class="site-blog-header">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-lg-8 text-center">
        <h1>Roxo Blog</h1>
        <p>
          By fusing strategy & design we help our partners build their brands, drive business, & stand out from the noise in saturated markets! Follow our blog for the latest case studies and projects.
        </p>
      </div>
    </div>
  </div>
</section>`
});Vvveb.Sections.add("roxo/site-client", {
    name: "Site client",
    image: Vvveb.themeBaseUrl + "/screenshots/roxo/site-client-thumb.jpeg",
    html: `<section class="site-client">
  <div class="container">
    <div class="row">
      <div class="col-12">
        <div class="section-title">
          <h2>Who trust our judgment</h2>
        </div>
        <div class="site-client-wrapper">
          <div class="site-client-item">
            <img src="images/clients/client-logo-one.png" alt="client-logo-one">
          </div>
          <div class="site-client-item">
            <img src="images/clients/client-logo-two.png" alt="client-logo-two">
          </div>
          <div class="site-client-item">
            <img src="images/clients/client-logo-three.png" alt="client-logo-three">
          </div>
          <div class="site-client-item">
            <img src="images/clients/client-logo-four.png" alt="client-logo-four">
          </div>
          <div class="site-client-item">
            <img src="images/clients/client-logo-five.png" alt="client-logo-five">
          </div>
          <div class="site-client-item">
            <img src="images/clients/client-logo-six.png" alt="client-logo-six">
          </div>
          <div class="site-client-item">
            <img src="images/clients/client-logo-seven.png" alt="client-logo-seven">
          </div>
          <div class="site-client-item">
            <img src="images/clients/client-logo-eight.png" alt="client-logo-eight">
          </div>
          <div class="site-client-item">
            <img src="images/clients/client-logo-nine.png" alt="client-logo-nine">
          </div>
          <div class="site-client-item">
            <img src="images/clients/client-logo-ten.png" alt="client-logo-ten">
          </div>
        </div>
      </div>
    </div>
  </div>
</section>`
});Vvveb.Sections.add("roxo/site-contact", {
    name: "Site contact",
    image: Vvveb.themeBaseUrl + "/screenshots/roxo/site-contact-thumb.jpeg",
    html: `<section class="site-contact">
  <div class="container">
    <div class="row">
      <div class="col-lg-5">
        <h1 class="site-contact-title">
          Don’t be shy.
          Say <span>Hello.</span>
        </h1>
      </div>
      <div class="col-lg-6 ml-auto">
        <div class="site-contact-form">
          <h4>Tell us about your project</h4>
          <form action="https://fabform.io/f/LWJRpmM" method="post">
            <div class="row">
              <div class="col-lg-6">
                <input type="text" class="form-control" name="first-name" id="first-name" placeholder="First Name">
              </div>
              <div class="col-lg-6">
                <input type="text" class="form-control" name="last-name" id="last-name" placeholder="Last Name">
              </div>
              <div class="col-lg-6">
                <input type="email" class="form-control" name="email" id="email" placeholder="Email">
              </div>
              <div class="col-lg-6">
                <div class="select-wrapper">
                  <select class="form-control" id="projectType">
                    <option value="" selected disabled hidden>Project Type</option>
                    <option value="gd">Graphics Design</option>
                    <option value="wb">Web Design</option>
                  </select>
                </div>
              </div>
              <div class="col-12">
                <textarea class="form-control" id="aboutProject" rows="6" placeholder="About the Project"></textarea>
              </div>
              <div class="col-12">
                <button type="submit" class="btn btn-primary" formtarget="_blank">
                  <span class="btn-area">
                    <span data-text="Send Message">
                      Send Message
                    </span>
                  </span>
                </button>
              </div>
            </div>
          </form>
          <p class="contact-form-generator">
            <strong>** </strong>
            <a href="https://fabform.io/" target="_blank">Static website forms</a>
          </p>
        </div>
      </div>
    </div>
  </div>
</section>`
});Vvveb.Sections.add("roxo/site-counter", {
    name: "Site counter",
    image: Vvveb.themeBaseUrl + "/screenshots/roxo/site-counter-thumb.jpeg",
    html: `<section class="site-counter" id="counter">
  <div class="container">
    <div class="row">
      <div class="col-12">
        <div class="section-title">
          <h2 class="text-white">The Proof is in the Pudding!</h2>
        </div>
      </div>
      <div class="col-lg-3 col-md-6">
        <div class="site-counter-item">
          <span class="site-counter-item-title">Happy Clients</span>
          <h3 class="site-counter-item-number">250+</h3>
        </div>
      </div>
      <div class="col-lg-3 col-md-6">
        <div class="site-counter-item">
          <span class="site-counter-item-title">Projects Completed</span>
          <h3 class="site-counter-item-number">100+</h3>
        </div>
      </div>
      <div class="col-lg-3 col-md-6">
        <div class="site-counter-item">
          <span class="site-counter-item-title">Cups of coffee</span>
          <h3 class="site-counter-item-number">350+</h3>
        </div>
      </div>
      <div class="col-lg-3 col-md-6">
        <div class="site-counter-item">
          <span class="site-counter-item-title">Telephone Talks</span>
          <h3 class="site-counter-item-number">775+</h3>
        </div>
      </div>
    </div>
  </div>
</section>`
});Vvveb.Sections.add("roxo/site-cta", {
    name: "Site cta",
    image: Vvveb.themeBaseUrl + "/screenshots/roxo/site-cta-thumb.jpeg",
    html: `<section class="site-cta">
  <div class="container">
    <div class="row">
      <div class="col-12 text-center">
        <h1 class="site-cta-title">LET’S WORK TOGETHER</h1>
        <ul class="site-cta-buttons">
          <li>
            <a href="contact.html" class="btn btn-secondary">
              <span class="btn-area">
                <span data-text="Submit Query">
                  Submit Query
                </span>
              </span>
            </a>
          </li>
          <li>
            <a href="portfolio.html" class="btn btn-primary">
              <span class="btn-area">
                <span data-text="Not Convinced">
                  Not Convinced
                </span>
              </span>
            </a>
          </li>
        </ul>
      </div>
    </div>
  </div>
</section>`
});Vvveb.Sections.add("roxo/site-expertise", {
    name: "Site expertise",
    image: Vvveb.themeBaseUrl + "/screenshots/roxo/site-expertise-thumb.jpeg",
    html: `<section class="site-expertise">
  <div class="container">
    <div class="row">
      <div class="col-md-5">
        <div class="section-title">
          <h2>Expertise</h2>
        </div>
      </div>
      <div class="col-md-6">
        <ul class="site-expertise-list">
          <li>Customer Experience Design</li>
          <li>Digital Products</li>
          <li>Development</li>
          <li>Campaign & Content</li>
          <li>Employer Branding</li>
          <li>Animation & Motion Graphics</li>
          <li>Packaging & Product Design</li>
          <li>Retail & Spacial</li>
          <li>Print & Editorial Design</li>
          <li>Concept/Text</li>
          <li>Information Design</li>
        </ul>
      </div>
    </div>
  </div>
</section>`
});Vvveb.Sections.add("roxo/site-footer", {
    name: "Site footer",
    image: Vvveb.themeBaseUrl + "/screenshots/roxo/site-footer-thumb.jpeg",
    html: `<footer class="site-footer">
  <div class="container">
    <div class="row">
      <div class="col-12">
        <div class="site-footer-logo">
          <a href="index.html">
            <img src="images/logo-footer.png" alt="logo-footer">
          </a>
        </div>
      </div>
      <div class="col-lg-3 col-md-6">
        <div class="site-footer-widget">
          <h5 class="site-footer-widget-title">Contact Info</h5>
          <p class="site-footer-widget-description">
            713 Elmwood St.
            <br>
            Prior Lake, MN 55372
            <br>
            <a href="tel:409-896-1444">409-896-1444</a>, <a href="tel:409-781-1308">409-781-1308</a>
            <br>
            <a href="mailto:">info@roxo.co</a>
          </p>
        </div>
      </div>
      <div class="col-lg-2 col-md-6">
        <div class="site-footer-widget">
          <h5 class="site-footer-widget-title">Sitemap</h5>
          <ul class="site-footer-widget-links">
            <li>
              <a href="about.html">About Comapny</a>
            </li>
            <li>
              <a href="portfolio.html">Projects</a>
            </li>
            <li>
              <a href="privacy-policy.html">Privacy Policy</a>
            </li>
            <li>
              <a href="terms-conditions.html">Terms & Condition</a>
            </li>
          </ul>
        </div>
      </div>
      <div class="col-lg-2 col-md-6">
        <div class="site-footer-widget">
          <h5 class="site-footer-widget-title">Social Media</h5>
          <ul class="site-footer-widget-links">
            <li>
              <a href="#">Medium</a>
            </li>
            <li>
              <a href="#">Behance</a>
            </li>
            <li>
              <a href="#">Dribbble</a>
            </li>
            <li>
              <a href="#">Instagram</a>
            </li>
          </ul>
        </div>
      </div>
      <div class="col-lg-3 col-md-6">
        <div class="site-footer-widget">
          <h5 class="site-footer-widget-title">We help brands:</h5>
          <p class="site-footer-widget-description">
            develop design solutions
            <br>
            produce valuable cultural content
            <br>
            create fresh brand experience
          </p>
        </div>
      </div>
      <div class="col-lg-2 col-12">
        <a href="#top" class="site-footer-widget-top">
          <img src="images/to-top.svg" alt="back-to-top">
          <p>
            I want to
            <br>
            visit again
          </p>
        </a>
      </div>
      <div class="col-12">
        <div class="site-footer-copyright">
          <p>© Copyright <span id="copyrightYear"></span> - All Rights Reserved by <a href="https://staticmania.com/" target="_blank">StaticMania</a>
          </p>
        </div>
      </div>
    </div>
  </div>
</footer>`
});Vvveb.Sections.add("roxo/site-hero", {
    name: "Site hero",
    image: Vvveb.themeBaseUrl + "/screenshots/roxo/site-hero-thumb.jpeg",
    html: `<!-- Site Hero Start -->
<section class="site-hero">
  <div class="container">
    <div class="row">
      <div class="col-lg-10 mx-auto">
        <div class="site-hero-content text-center">
          <h6>WE WORK HARD, WE PLAY HARD</h6>
          <h1>
            We’re a Design Studio
            <br>
            That Belies In the Great Ideas
          </h1>
          <ul class="site-hero-content-buttons">
            <li>
              <a href="#project" class="btn btn-secondary scroll-to">
                <span class="btn-area">
                  <span data-text="See Our Works">
                    See Our Works
                  </span>
                </span>
              </a>
            </li>
            <li>
              <a href="contact.html" class="btn btn-primary">
                <span class="btn-area">
                  <span data-text="Connect with us">
                    Connect with us
                  </span>
                </span>
              </a>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </div>
  <a href="#counter" class="site-hero-scroll scroll-to">
    <img src="images/arrow-down.svg" alt="arrow-down">
  </a>
</section>
<!-- Site Hero End -->`
});Vvveb.Sections.add("roxo/site-navigation", {
    name: "Site navigation",
    image: Vvveb.themeBaseUrl + "/screenshots/roxo/site-navigation-thumb.jpeg",
    html: `<nav class="navbar navbar-expand-lg site-navigation">
  <div class="container">
    <a class="navbar-brand" href="/">
      <img src="images/logo.png" alt="logo" />
    </a>
    <button class="navbar-toggler collapsed" type="button" data-toggle="collapse" data-target="#sitenavbar">
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
    </button>

    <div class="collapse navbar-collapse" id="sitenavbar">
      <ul class="navbar-nav ms-auto main-nav">
        <li class="nav-item">
          <a class="nav-link" href="index.html">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="about.html">About</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="portfolio.html">Portfolio</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="blog.html">Blog</a>
        </li>
        <li class="nav-item">
          <a class="nav-link btn btn-sm btn-primary btn-sm-rounded" href="contact.html">
            <span class="btn-area">
              <span data-text="Get in touch">
                Get in touch
              </span>
            </span>
          </a>
        </li>
      </ul>
    </div>
  </div>
</nav>`
});Vvveb.Sections.add("roxo/site-project-header", {
    name: "Site project header",
    image: Vvveb.themeBaseUrl + "/screenshots/roxo/site-project-header-thumb.jpeg",
    html: `<section class="site-project-header">
  <div class="container">
    <div class="row align-items-center">
      <div class="col-lg-8">
        <div class="site-project-header-content">
          <h1>
            We build better <span>products</span>
            to help our clients build
            better <span>companies</span>
          </h1>
        </div>
      </div>
      <div class="col-lg-4">
        <a href="#project" class="site-project-header-action scroll-to">
          <span>Scroll Down</span>
          <img src="images/arrow-down.svg" alt="arrow-down">
        </a>
      </div>
    </div>
  </div>
</section>`
});Vvveb.Sections.add("roxo/site-project-single", {
    name: "Site project single",
    image: Vvveb.themeBaseUrl + "/screenshots/roxo/site-project-single-thumb.jpeg",
    html: `<section class="site-project-single-section">
  <div class="container">
    <div class="row">
      <div class="col-lg-8 mx-auto">
        <div class="site-project-single">
          <h1>
            SEAMLESS WATCH
          </h1>
          <div class="site-project-single-description">
            <p>
              The “Seamless Watch” watch has all the features that users expect in a digital watch, and some unusual features.
            </p>
            <p>
              The watch has the following features:
              <br>
              <br>
              Time and date displayed on the screen. Current time is in large numbers, date is in small numbers above it.
              <br>
              <br>
              Light: Pressing the light button on the side of the watch activates a light while the button is pressed. Pressing and holding that button for 3 seconds turns on the light and keeps it on, until the button is held again for 3 seconds or up to 2 hours. After 2 hours, it will automatically turn off.
              <br>
              <br>
              Alarm. A daily alarm may be set for a given time. The alarm may be enabled or disabled. When the alarm is enabled and the alarm time is reached, the watch will beep fast for 5 seconds, then slowly for 30 seconds, then fast for another 5 seconds. Pressing any button stops the alarm sound (in addition to performing its normal function).
              <br>
              <br>
              Timer. Timer mode shows a count-up timer that starts at 00:00. When the timer is started, it counts up. Pressing the start/stop button will pause the timer, pressing it again continues counting up. Pressing and holding the button for 3 seconds resets the timer to 00:00 and stops counting.
              <br>
              <br>
              Mystery answer. After entering this mode, the screen initially displays “ask now”. The user may ask a yes-or-no question aloud and press the start/stop button, this will display a randomly selected answer that is one of the following: “yeah”, “yeah right”, “no”, “no doubt”, “keep trying”, “keep dreaming”. Whenever the display has more than one word, only one word is displayed for 2 seconds, then the other word is displayed for 2 seconds, alternately. The answer is displayed until the user leaves this mode, or he/she presses start/stop again for a new answer.
            </p>
            <p>
              Note: these strings are for the English version of the watch, we will need to use completely different strings in other countries without reprogramming the logic of the watch.
            </p>
            <p>
              The user may cycle among all modes (date/time, timer, mystery answer) by pressing the mode button.
            </p>
          </div>
          <div class="site-project-single-image">
            <img src="images/projects/project-details-image-one.jpg" alt="project image">
            <img src="images/projects/project-details-image-two.jpg" alt="project image">
          </div>
          <div class="site-project-single-action">
            <a href="project-single.html">
              <span class="link-area">
                <span data-text="Next Project">
                  Next Project
                </span>
              </span>
              <img src="images/to-top.svg" alt="next project">
            </a>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>`
});Vvveb.Sections.add("roxo/site-project-with-pagination", {
    name: "Site project with pagination",
    image: Vvveb.themeBaseUrl + "/screenshots/roxo/site-project-with-pagination-thumb.jpeg",
    html: `<section class="site-project" id="project">
  <div class="container">
    <div class="row">
      <div class="col-lg-6">
        <div class="site-project-item">
          <div class="site-project-item-thumb">
            <img src="images/projects/project-thumb-one.jpg" alt="project-thumb-one">
          </div>
          <div class="site-project-item-content">
            <span>UX UI</span>
            <h3>USE-LESS BRAND</h3>
            <a href="project-single.html" class="read-more">view project</a>
          </div>
        </div>
      </div>
      <div class="col-lg-6">
        <div class="site-project-item">
          <div class="site-project-item-thumb">
            <img src="images/projects/project-thumb-two.jpg" alt="project-thumb-two">
          </div>
          <div class="site-project-item-content">
            <span>PRODUCT DESIGN</span>
            <h3>OSEN CLOCK</h3>
            <a href="project-single.html" class="read-more">view project</a>
          </div>
        </div>
      </div>
      <div class="col-lg-6">
        <div class="site-project-item">
          <div class="site-project-item-thumb">
            <img src="images/projects/project-thumb-three.jpg" alt="project-thumb-three">
          </div>
          <div class="site-project-item-content">
            <span>REBRAND</span>
            <h3>SEAMLESS WATCH</h3>
            <a href="project-single.html" class="read-more">view project</a>
          </div>
        </div>
      </div>
      <div class="col-lg-6">
        <div class="site-project-item">
          <div class="site-project-item-thumb">
            <img src="images/projects/project-thumb-four.jpg" alt="project-thumb-four">
          </div>
          <div class="site-project-item-content">
            <span>PRODUCT LABEL</span>
            <h3>KIO TAPE</h3>
            <a href="project-single.html" class="read-more">view project</a>
          </div>
        </div>
      </div>
      <div class="col-12">
        <div class="site-project-pagination">
          <nav>
            <ul class="pagination">
              <li class="page-item active">
                <a class="page-link" href="#">1</a>
              </li>
              <li class="page-item">
                <a class="page-link" href="#">2</a>
              </li>
              <li class="page-item">
                <a class="page-link" href="#">3</a>
              </li>
              <li class="page-item">
                <a class="page-link" href="#">Next</a>
              </li>
            </ul>
          </nav>
        </div>
      </div>
    </div>
  </div>
</section>`
});Vvveb.Sections.add("roxo/site-project", {
    name: "Site project",
    image: Vvveb.themeBaseUrl + "/screenshots/roxo/site-project-thumb.jpeg",
    html: `<section class="site-project" id="project">
  <div class="container">
    <div class="row">
      <div class="col-12">
        <div class="section-title">
          <h2>OUR RECENT WORKS</h2>
          <p>Crafting experiences and seeking to make the complex clear & beautiful.</p>
        </div>
      </div>
      <div class="col-lg-6 col-md-10 mx-auto">
        <div class="site-project-item">
          <div class="site-project-item-thumb">
            <img src="images/projects/project-thumb-one.jpg" alt="project-thumb-one">
          </div>
          <div class="site-project-item-content">
            <span>UX UI</span>
            <h3>USE-LESS BRAND</h3>
            <a href="project-single.html" class="read-more">view project</a>
          </div>
        </div>
      </div>
      <div class="col-lg-6 col-md-10 mx-auto">
        <div class="site-project-item">
          <div class="site-project-item-thumb">
            <img src="images/projects/project-thumb-two.jpg" alt="project-thumb-two">
          </div>
          <div class="site-project-item-content">
            <span>PRODUCT DESIGN</span>
            <h3>OSEN CLOCK</h3>
            <a href="project-single.html" class="read-more">view project</a>
          </div>
        </div>
      </div>
      <div class="col-lg-6 col-md-10 mx-auto">
        <div class="site-project-item">
          <div class="site-project-item-thumb">
            <img src="images/projects/project-thumb-three.jpg" alt="project-thumb-three">
          </div>
          <div class="site-project-item-content">
            <span>REBRAND</span>
            <h3>SEAMLESS WATCH</h3>
            <a href="project-single.html" class="read-more">view project</a>
          </div>
        </div>
      </div>
      <div class="col-lg-6 col-md-10 mx-auto">
        <div class="site-project-item">
          <div class="site-project-item-thumb">
            <img src="images/projects/project-thumb-four.jpg" alt="project-thumb-four">
          </div>
          <div class="site-project-item-content">
            <span>PRODUCT LABEL</span>
            <h3>KIO TAPE</h3>
            <a href="project-single.html" class="read-more">view project</a>
          </div>
        </div>
      </div>
      <div class="col-12 text-center text-lg-left">
        <a href="portfolio.html" class="site-project-cta">MORE WORKS</a>
      </div>
    </div>
  </div>
</section>`
});Vvveb.Sections.add("roxo/site-team", {
    name: "Site team",
    image: Vvveb.themeBaseUrl + "/screenshots/roxo/site-team-thumb.jpeg",
    html: `<section class="site-team">
  <div class="container">
    <div class="row">
      <div class="col-12">
        <div class="section-title">
          <h2>
            team that makes the difference.
          </h2>
        </div>
      </div>
      <div class="col-lg-4 col-md-6">
        <div class="site-team-member">
          <div class="site-team-member-image">
            <img src="images/team/team-member-one.jpg" alt="team-member-one">
          </div>
          <div class="site-team-member-content">
            <h3>PABLO ESCOBAR</h3>
            <p>Creative Director</p>
            <ul class="site-team-member-social">
              <li>
                <a href="#">
                  <i class="fa fa-medium"></i>
                </a>
              </li>
              <li>
                <a href="#">
                  <i class="fa fa-linkedin"></i>
                </a>
              </li>
              <li>
                <a href="#">
                  <i class="fa fa-instagram"></i>
                </a>
              </li>
            </ul>
          </div>
        </div>
      </div>
      <div class="col-lg-4 col-md-6">
        <div class="site-team-member">
          <div class="site-team-member-image">
            <img src="images/team/team-member-two.jpg" alt="team-member-two">
          </div>
          <div class="site-team-member-content">
            <h3>MONTINO RIAU</h3>
            <p>Product Manager</p>
            <ul class="site-team-member-social">
              <li>
                <a href="#">
                  <i class="fa fa-medium"></i>
                </a>
              </li>
              <li>
                <a href="#">
                  <i class="fa fa-linkedin"></i>
                </a>
              </li>
              <li>
                <a href="#">
                  <i class="fa fa-instagram"></i>
                </a>
              </li>
            </ul>
          </div>
        </div>
      </div>
      <div class="col-lg-4 col-md-6">
        <div class="site-team-member">
          <div class="site-team-member-image">
            <img src="images/team/team-member-three.jpg" alt="team-member-three">
          </div>
          <div class="site-team-member-content">
            <h3>ALEX NAASRI</h3>
            <p>Chief Design Officer</p>
            <ul class="site-team-member-social">
              <li>
                <a href="#">
                  <i class="fa fa-medium"></i>
                </a>
              </li>
              <li>
                <a href="#">
                  <i class="fa fa-linkedin"></i>
                </a>
              </li>
              <li>
                <a href="#">
                  <i class="fa fa-instagram"></i>
                </a>
              </li>
            </ul>
          </div>
        </div>
      </div>
      <div class="col-lg-4 col-md-6">
        <div class="site-team-member">
          <div class="site-team-member-image">
            <img src="images/team/team-member-four.jpg" alt="team-member-four">
          </div>
          <div class="site-team-member-content">
            <h3>HONGMAN CHIOA</h3>
            <p>UX Researcher</p>
            <ul class="site-team-member-social">
              <li>
                <a href="#">
                  <i class="fa fa-medium"></i>
                </a>
              </li>
              <li>
                <a href="#">
                  <i class="fa fa-linkedin"></i>
                </a>
              </li>
              <li>
                <a href="#">
                  <i class="fa fa-instagram"></i>
                </a>
              </li>
            </ul>
          </div>
        </div>
      </div>
      <div class="col-lg-4 col-md-6">
        <div class="site-team-member">
          <div class="site-team-member-image">
            <img src="images/team/team-member-five.jpg" alt="team-member-five">
          </div>
          <div class="site-team-member-content">
            <h3>SANTIO ANDRESS</h3>
            <p>Content Researcher</p>
            <ul class="site-team-member-social">
              <li>
                <a href="#">
                  <i class="fa fa-medium"></i>
                </a>
              </li>
              <li>
                <a href="#">
                  <i class="fa fa-linkedin"></i>
                </a>
              </li>
              <li>
                <a href="#">
                  <i class="fa fa-instagram"></i>
                </a>
              </li>
            </ul>
          </div>
        </div>
      </div>
      <div class="col-lg-4 col-md-6">
        <div class="site-team-member">
          <div class="site-team-member-image">
            <img src="images/team/team-member-six.jpg" alt="team-member-six">
          </div>
          <div class="site-team-member-content">
            <h3>RAMESH PAUL</h3>
            <p>Creative Designer</p>
            <ul class="site-team-member-social">
              <li>
                <a href="#">
                  <i class="fa fa-medium"></i>
                </a>
              </li>
              <li>
                <a href="#">
                  <i class="fa fa-linkedin"></i>
                </a>
              </li>
              <li>
                <a href="#">
                  <i class="fa fa-instagram"></i>
                </a>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>`
});Vvveb.Sections.add("roxo/site-testimonial", {
    name: "Site testimonial",
    image: Vvveb.themeBaseUrl + "/screenshots/roxo/site-testimonial-thumb.jpeg",
    html: `<section class="site-testimonial">
  <div class="container">
    <div class="row">
      <div class="col-12">
        <div class="section-title">
          <h2>
            OPINION FROM REAL PEOPLE
          </h2>
          <p>
            What clients says about our services.
          </p>
        </div>
      </div>
      <div class="col-lg-4 col-md-6">
        <div class="site-testimonial-item">
          <div class="site-testimonial-item-header">
            <div class="thumb">
              <img src="images/testimonial/user-thumb-one.jpg" alt="user-thumb-one">
            </div>
            <div class="person">
              <h5>Simonns Hodge</h5>
              <p>CEO, Credito</p>
            </div>
          </div>
          <p class="site-testimonial-item-body">
            Trust us we looked for a very long time and wasted thousands of dollars testing other teams, freelancers, and outsource companies.
          </p>
        </div>
      </div>
      <div class="col-lg-4 col-md-6">
        <div class="site-testimonial-item">
          <div class="site-testimonial-item-header">
            <div class="thumb">
              <img src="images/testimonial/user-thumb-two.jpg" alt="user-thumb-two">
            </div>
            <div class="person">
              <h5>Rekon Montino</h5>
              <p>CDO, Bulmuci</p>
            </div>
          </div>
          <p class="site-testimonial-item-body">
            Roxo products have allowed us to deliver better support to all our clients. The agility with which we can implement new features and workflows is a key element.
          </p>
        </div>
      </div>
      <div class="col-lg-4 col-md-6">
        <div class="site-testimonial-item">
          <div class="site-testimonial-item-header">
            <div class="thumb">
              <img src="images/testimonial/user-thumb-three.jpg" alt="user-thumb-three">
            </div>
            <div class="person">
              <h5>Ryan Hillary</h5>
              <p>MD, Udilamo</p>
            </div>
          </div>
          <p class="site-testimonial-item-body">
            We’re a really busy restaurant, and roxo gives our customers a easy way to order, pay, and pick up their food so they can beat the line and beat that lunch rush.
          </p>
        </div>
      </div>
      <div class="col-lg-4 col-md-6">
        <div class="site-testimonial-item">
          <div class="site-testimonial-item-header">
            <div class="thumb">
              <img src="images/testimonial/user-thumb-four.jpg" alt="user-thumb-four">
            </div>
            <div class="person">
              <h5>Dockrel Kahn</h5>
              <p>PM, Walmet</p>
            </div>
          </div>
          <p class="site-testimonial-item-body">
            Trust us we looked for a very long time and wasted thousands of dollars testing other teams, freelancers, and outsource companies.
          </p>
        </div>
      </div>
      <div class="col-lg-4 col-md-6">
        <div class="site-testimonial-item">
          <div class="site-testimonial-item-header">
            <div class="thumb">
              <img src="images/testimonial/user-thumb-five.jpg" alt="user-thumb-five">
            </div>
            <div class="person">
              <h5>Orino Monteno</h5>
              <p>CEO, Axion</p>
            </div>
          </div>
          <p class="site-testimonial-item-body">
            Roxo products have allowed us to deliver better support to all our clients. The agility with which we can implement new features and workflows is a key element.
          </p>
        </div>
      </div>
      <div class="col-lg-4 col-md-6">
        <div class="site-testimonial-item">
          <div class="site-testimonial-item-header">
            <div class="thumb">
              <img src="images/testimonial/user-thumb-six.jpg" alt="user-thumb-six">
            </div>
            <div class="person">
              <h5>Welfo Roy</h5>
              <p>PDO, Komoyo</p>
            </div>
          </div>
          <p class="site-testimonial-item-body">
            We’re a really busy restaurant, and roxo gives our customers a easy way to order, pay, and pick up their food so they can beat the line and beat that lunch rush.
          </p>
        </div>
      </div>
    </div>
  </div>
</section>`
});Vvveb.Sections.add("roxo/terms-conditions", {
    name: "Terms conditions",
    image: Vvveb.themeBaseUrl + "/screenshots/roxo/terms-conditions-thumb.jpeg",
    html: `<section class="site-project-single-section">
  <div class="container">
    <div class="row">
      <div class="col-lg-8 mx-auto">
        <div class="site-project-single">
          <h1>
            Terms & Conditions
          </h1>
          <div class="site-project-single-description">
            <h4>What is Lorem Ipsum?</h4>
            <p>
              Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum
            </p>
            <h4>What is Lorem Ipsum?</h4>
            <p>
              Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum
            </p>
            <h4>What is Lorem Ipsum?</h4>
            <p>
              Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum
            </p>
            <h4>What is Lorem Ipsum?</h4>
            <p>
              Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum
            </p>
            <h4>What is Lorem Ipsum?</h4>
            <p>
              Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum
            </p>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>`
});
	Vvveb.SectionsGroup["Roxo"] = ["roxo/privacy-policy","roxo/site-about-header","roxo/site-blog-header","roxo/site-client","roxo/site-contact","roxo/site-counter","roxo/site-cta","roxo/site-expertise","roxo/site-footer","roxo/site-hero","roxo/site-navigation","roxo/site-project-header","roxo/site-project-single","roxo/site-project-with-pagination","roxo/site-project","roxo/site-team","roxo/site-testimonial","roxo/terms-conditions"];
